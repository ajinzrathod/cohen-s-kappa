import sqlite3


def connection():
    conn = sqlite3.connect('login.db')
    conn.row_factory = dict_factory
    c = conn.cursor()
    return conn, c


def dict_factory(cursor, row):
    d = {}
    for idx, col in enumerate(cursor.description):
        d[col[0]] = row[idx]
    return d


def get_tables():
    con, c = connection()
    sql_query = """SELECT name FROM sqlite_master 
        WHERE type='table';"""
    res = c.execute(sql_query)
    data = res.fetchall()
    return data
