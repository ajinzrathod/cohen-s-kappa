from flask import Flask, render_template, url_for, request, redirect, session
# import sqlite3
from utils import *
from config_parser import ConfigParser
import random
from sklearn.metrics import cohen_kappa_score

# conn = sqlite3.connect('login.db')
# c = conn.cursor()
app = Flask(__name__)
app.secret_key = "1234567890"
config_parser = ConfigParser()
answers, tweet = config_parser.get_config()


@app.route('/', methods=['GET', 'POST'])
def index():
    """Used for login procedure"""
    if request.method == "POST":

        if 'username' in request.form and 'password' in request.form:

            con, c = connection()
            # con.row_factory = dict_factory
            username = request.form['username']
            password = request.form['password']
            if username == "admin" and password == "admin":
                return redirect(url_for('admin'))

            info = [username, password]
            res = c.execute('SELECT * FROM LOGIN WHERE username=? and password=?', info)
            res = res.fetchone()

            con.commit()
            # print(res, test)
            try:
                if username == res['username'] and password == res['password']:

                    session['login_flag'] = True
                    session['login_user'] = res['name']
                    return redirect(url_for('profile'))
            except:
                return "Credential wrong"

    return render_template('login.html')


@app.route('/register', methods=['GET', 'POST'])
def register():
    """Registration function"""
    if request.method == "POST":

        if 'name' in request.form and 'username' in request.form and 'password' in request.form:
            con, c = connection()

            name = request.form['name']
            username = request.form['username']
            password = request.form['password']

            # print('INSERT INTO LOGIN VALUES(?, ?, ?);', name, username, password)
            info = [name, username, password]
            if '' in info:
                return "Null value present"
            res = c.execute('INSERT INTO LOGIN VALUES(?, ?, ?);', info)

            con.commit()

            if res:
                return redirect(url_for('index'))

    return render_template('register.html')


@app.route('/profile', methods=['GET', 'POST'])
def profile():
    """it will render all the tweets for user to lable it."""

    if session['login_flag']:
        """getting random 100 tweets"""
        confirm_tweets, random_tweets = config_parser.get_random_config()
        total_tweets = []
        total_tweets.extend(confirm_tweets)
        total_tweets.extend(random_tweets)

        """coloring the previous answers"""
        try:
            con, c = connection()
            if " " in session["login_user"]:
                table_name = session['login_user'].replace(" ", '')
            else:
                table_name = session['login_user']

            res = c.execute("SELECT tweet FROM " + table_name + "")
            res = res.fetchall()
            # print(res)
            answered_tweet = []
            for i in res:
                answered_tweet.append(i['tweet'])
        except:
            answered_tweet = []

        if request.method == "POST":
            # con, c = connection()
            res = request.form
            # print(type(res))

            """from here we can send res(result) to any function for backend processing"""

            if res is not None:
                con, c = connection()
                if " " in session["login_user"]:
                    table_name = session['login_user'].replace(" ", '')
                else:
                    table_name = session['login_user']
                db_res = c.execute(
                    "CREATE TABLE IF NOT EXISTS " + table_name + ""
                    "(tweet VARCHAR(255) PRIMARY KEY, answers VARCHAR(255));")

                tweets = res.keys()
                user_answers = res.values()
                data = tuple(zip(tweets, user_answers))

                insert_res = c.executemany("INSERT OR REPLACE INTO "+table_name+" (tweet, answers) VALUES(?, ?)", data)

                con.commit()
                return render_template('ans.html', res=res)
                # print("redirecting")
        return render_template('profile.html', len=len(tweet), test=tweet, name=session['login_user'], answered_tweet=answered_tweet, total_tweets=total_tweets)
    else:
        return redirect(url_for('index'))


@app.route('/ans', methods=['GET', 'POST'])
def ans():
    """page to show the answers given by user."""
    res = request.args
    # print(type(res))
    # res = eval(res).to_dict()
    # res = json.loads(res)
    print(res)
    if request.method == "POST":
        session['login_flag'] = False
        session['login_user'] = ""
        return redirect(url_for('index'))

    return render_template('ans.html', len=len(res), res=res)


@app.route('/logout', methods=['GET', 'POST'])
def logout():
    """for logout call this function"""
    session['login_flag'] = False
    session['login_user'] = ""
    return redirect(url_for('index'))


@app.route('/admin', methods=['GET', 'POST'])
def admin():
    """
    this is for rendering admin panel and get all possible tables.
    if the the process is clicked it will return further processes.
    """

    con, c = connection()
    tables = get_tables()
    res_table = {}
    for table in tables:
        table_name = table['name']
        fetch_data = c.execute("SELECT * FROM "+table_name+";")
        table_data = fetch_data.fetchall()
        res_table[table_name] = table_data
    """can call process function or render it."""
    if request.method == "POST":
        res = request.form
        del res_table['login']
        process_table = res_table
        # redirect(url_for('process'))
        # process(process_table)
        score = 0
        table_key = list(process_table.keys())
        # print(table_key)
        key_list = range(len(table_key))
        users = random.sample(set(key_list), 2)
        user_name = []
        final_table = dict()
        process_value = []
        for user in users:
            user_name.append(table_key[user])
            list_values = process_table[table_key[user]]
            values = {}
            for item in list_values:
                tweet = item['tweet']
                values[tweet] = item['answers']
            # list_keys = process_table[table_key[user]]
            final_table[table_key[user]] = values
            process_value.append(list(map(int, list(values.values()))))

        process_value_2 = []
        process_value_2.append([])
        process_value_2.append([])
        max_size = max(len(final_table[user_name[0]]), len(final_table[user_name[1]]))

        if len(final_table[user_name[0]]) >= len(final_table[user_name[1]]):
            for i in final_table[user_name[1]].keys():
                if i in final_table[user_name[0]].keys():
                    process_value_2[0].append(int(final_table[user_name[0]][i]))
                    process_value_2[1].append(int(final_table[user_name[1]][i]))
        else:
            for i in final_table[user_name[0]].keys():
                if i in final_table[user_name[1]].keys():
                    process_value_2[0].append(int(final_table[user_name[0]][i]))
                    process_value_2[1].append(int(final_table[user_name[1]][i]))

        # score = cohen_kappa_score(process_value[0], process_value[1])
        score2 = cohen_kappa_score(process_value_2[0], process_value_2[1])
        # return str(process_value)
        return render_template('process.html', process_table=process_table, score=score2, user_name=user_name, process_value=process_value_2, final_table=final_table)
    return render_template('admin.html', tables=res_table)


@app.route('/process', methods=['GET', 'POST'])
def process(process_table):
    """process function"""
    return render_template('process.html', process_table=process_table)


if __name__ == "__main__":

    app.run(use_reloader=True, debug=True)
