import pandas as pd
import random


class ConfigParser:
    def __init__(self):
        self.res_dict = dict()
        excel_file = pd.ExcelFile('Tagged_Total Tweets _ 300.xlsx')
        que_sheet = excel_file.parse(excel_file.sheet_names[0])
        self.res_dict = que_sheet.to_dict()

    def get_config(self):
        answers = self.res_dict['Class']
        tweet = self.res_dict['Tweet']
        # print(self.res_dict)
        return answers, tweet

    def get_random_config(self):
        answers, tweet = self.get_config()
        tweet_list = list(tweet.values())
        confirm_tweets = tweet_list[0:30]
        remaining_list = list(set(tweet_list)-set(confirm_tweets))
        random_tweets = random.sample(set(remaining_list), 70)
        return confirm_tweets, random_tweets
